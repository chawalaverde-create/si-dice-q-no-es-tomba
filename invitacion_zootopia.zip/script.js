const ribbon = document.getElementById("ribbonWrapper");
const content = document.getElementById("content");
const yesBtn = document.getElementById("yesBtn");
const noBtn = document.getElementById("noBtn");
const answer = document.getElementById("answer");

// abrir sobre
ribbon.addEventListener("click", () => {
  gsap.to(ribbon, {
    opacity: 0,
    y: -150,
    duration: 0.8,
    onComplete: () => {
      ribbon.style.display = "none";
      content.style.display = "block";

      gsap.from(content, {
        scale: 0.6,
        opacity: 0,
        duration: 0.8,
        ease: "back.out(1.5)"
      });
    }
  });
});

// sí
yesBtn.addEventListener("click", () => {
  content.style.display = "none";
  answer.style.display = "block";

  gsap.from(answer, {
    scale: 0.5,
    opacity: 0,
    duration: 0.6,
    ease: "back.out(1.3)"
  });
});

// no escapa
noBtn.addEventListener("mouseover", () => {
  const x = (Math.random() - 0.5) * 300;
  const y = (Math.random() - 0.5) * 200;

  gsap.to(noBtn, {
    x: x,
    y: y,
    duration: 0.3
  });
});
